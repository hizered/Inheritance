﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Task_CKP
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void CircleCalc_Click(object sender, RoutedEventArgs e)
        {
            Circle C;
            double p, s;

            C = new Circle(Convert.ToDouble(CircleRadius.Text));
            p = C.Perimeter();
            s = C.Square();
            ResultCircle.Text = $"Ответ:периметр окружности = {Math.Round(p, 2, MidpointRounding.AwayFromZero)}, Площадь = {Math.Round(s, 2, MidpointRounding.AwayFromZero)}";
        }

        private void RectangleCalc_Click(object sender, RoutedEventArgs e)
        {
            Rectangle R;
            double p, s;

            R = new Rectangle((Convert.ToDouble(RectangleStorona1.Text)), Convert.ToDouble(RectangleStorona2.Text));
            p = R.Perimeter();
            s = R.Square();
            ResultRectangle.Text = $"Ответ:периметр прямоугольника = {Math.Round(p, 2, MidpointRounding.AwayFromZero)}, Площадь = {Math.Round(s, 2, MidpointRounding.AwayFromZero)}";
        }

        private void TriangleCacl_Click(object sender, RoutedEventArgs e)
        {
            Triangle T;
            double p, s;

            T = new Triangle((Convert.ToDouble(TriangleStorona1.Text)), Convert.ToDouble(TriangleStorona2.Text), Convert.ToDouble(TriangleStorona3.Text));
            p = T.Perimeter();
            s = T.Square();
            ResultTriangle.Text = $"Ответ:периметр треугольника = {Math.Round(p, 2, MidpointRounding.AwayFromZero)}, Площадь = {Math.Round(s, 2, MidpointRounding.AwayFromZero)}";
        }
    }
}
